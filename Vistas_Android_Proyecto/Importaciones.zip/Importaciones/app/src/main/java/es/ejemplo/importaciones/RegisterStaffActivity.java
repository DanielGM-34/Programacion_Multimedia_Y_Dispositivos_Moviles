package es.ejemplo.importaciones;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterStaffActivity extends AppCompatActivity {

    EditText nombre, email, password, confirmar, codigoAcceso;
    Button btnRegistrar, btnSocio, btnStaff;
    CheckBox checkboxPrivacidad;
    TextView loginLink;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register_staff);

        // Referencias
        nombre = findViewById(R.id.nombre);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmar = findViewById(R.id.confirmar);
        checkboxPrivacidad = findViewById(R.id.checkbox_privacidad);
        btnRegistrar = findViewById(R.id.btn_registrar);
        btnSocio = findViewById(R.id.btn_socio);
        btnStaff = findViewById(R.id.btn_staff);
        loginLink = findViewById(R.id.login_link);

        // Estado inicial: STAFF activo
        activarStaff();

        // Pulsar SOCIO → ir al registro de usuario
        btnSocio.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterStaffActivity.this, RegisterUserActivity.class);
            startActivity(intent);
        });

        // Pulsar STAFF (ya estás aquí)
        btnStaff.setOnClickListener(v -> activarStaff());

        // Botón registrar
        btnRegistrar.setOnClickListener(v -> {

            Toast.makeText(
                    this,
                    "Registro de STAFF completado correctamente",
                    Toast.LENGTH_LONG
            ).show();

            startActivity(new Intent(RegisterStaffActivity.this, LoginStaffActivity.class));

//            if (validarCampos()) {
//
//                Toast.makeText(
//                        this,
//                        "Registro de STAFF completado correctamente",
//                        Toast.LENGTH_LONG
//                ).show();
//
//                startActivity(new Intent(RegisterStaffActivity.this, LoginStaffActivity.class));
//            }
        });

        // Enlace login
        loginLink.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterStaffActivity.this, LoginStaffActivity.class);
            startActivity(intent);
        });
    }

    // ---------------------------------------------------
    //   VALIDACIÓN LIMPIA
    // ---------------------------------------------------
    /*
    private boolean validarCampos() {

        boolean valido = true;

        String nom = nombre.getText().toString().trim();
        String correo = email.getText().toString().trim();
        String pass = password.getText().toString().trim();
        String conf = confirmar.getText().toString().trim();

        if (nom.isEmpty()) {
            nombre.setError("Introduce el nombre");
            valido = false;
        }

        if (correo.isEmpty()) {
            email.setError("Introduce el correo");
            valido = false;
        }

        if (pass.isEmpty()) {
            password.setError("Introduce una contraseña");
            valido = false;
        }

        if (!pass.equals(conf)) {
            confirmar.setError("Las contraseñas no coinciden");
            valido = false;
        }



        if (!checkboxPrivacidad.isChecked()) {
            Toast.makeText(this, "Debes aceptar las políticas de privacidad", Toast.LENGTH_SHORT).show();
            valido = false;
        }

        return valido;
    }

     */

    // ---------------------------------------------------
    //   ESTILO DE BOTONES SOCIO / STAFF
    // ---------------------------------------------------
    private void activarStaff() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnStaff.setBackgroundTintList(getColorStateList(R.color.verde_lima));
            btnStaff.setTextColor(getColor(R.color.negro));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnSocio.setBackgroundTintList(getColorStateList(R.color.gris_oscuro));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnSocio.setTextColor(getColor(R.color.blanco));
        }
    }
}
