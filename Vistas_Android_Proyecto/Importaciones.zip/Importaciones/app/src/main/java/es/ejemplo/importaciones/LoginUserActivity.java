package es.ejemplo.importaciones;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class LoginUserActivity extends AppCompatActivity {

    EditText email, password;
    Button btnLogin, btnSocio, btnStaff;
    TextView registerLink, forgotPassword;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_user);

        // Referencias
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        btnLogin = findViewById(R.id.btn_login);
        btnSocio = findViewById(R.id.btn_socio);
        btnStaff = findViewById(R.id.btn_staff);
        registerLink = findViewById(R.id.register_link);
        forgotPassword = findViewById(R.id.forgot_password);

        // Estado inicial: SOCIO activo
        activarSocio();

        // Pulsar SOCIO
        btnSocio.setOnClickListener(v -> activarSocio());

        // Pulsar STAFF → ir al login staff
        btnStaff.setOnClickListener(v -> {
            Intent intent = new Intent(LoginUserActivity.this, LoginStaffActivity.class);
            startActivity(intent);
        });

        // Botón iniciar sesión
        btnLogin.setOnClickListener(v -> {
            if (validarCampos()) {
                Toast.makeText(this, "Inicio de sesión correcto", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LoginUserActivity.this, RegisterUserActivity.class));
            }
        });

        // Enlace registro
        registerLink.setOnClickListener(v -> {
            Intent intent = new Intent(LoginUserActivity.this, RegisterUserActivity.class);
            startActivity(intent);
        });

        // Olvidaste tu contraseña
        forgotPassword.setOnClickListener(v ->
                Toast.makeText(this, "Función no implementada aún", Toast.LENGTH_SHORT).show()
        );
    }

    // ---------------------------------------------------
    //   VALIDACIÓN LIMPIA (sin returns dispersos)
    // ---------------------------------------------------


    private boolean validarCampos() {

        boolean valido = true;

        String correo = email.getText().toString().trim();
        String clave = password.getText().toString().trim();

        if (correo.isEmpty()) {
            email.setError("Introduce tu correo");
            valido = false;
        }

        if (clave.isEmpty()) {
            password.setError("Introduce tu contraseña");
            valido = false;
        }

        return valido;
    }

    // ---------------------------------------------------
    //   ESTILO DE BOTONES SOCIO / STAFF
    // ---------------------------------------------------
    private void activarSocio() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnSocio.setBackgroundTintList(getColorStateList(R.color.verde_lima));
            btnSocio.setTextColor(getColor(R.color.negro));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnStaff.setBackgroundTintList(getColorStateList(R.color.gris_oscuro));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnStaff.setTextColor(getColor(R.color.blanco));
        }
    }
}
