package es.ejemplo.importaciones;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PanelUsuarioActivity extends AppCompatActivity {

    Button btnClases, btnChat, btnRM, btnPerfil, btnTienda;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panel_usuario);

        btnClases = findViewById(R.id.btn_clases);
        btnChat = findViewById(R.id.btn_chat);
        btnRM = findViewById(R.id.btn_rm);
        btnPerfil = findViewById(R.id.btn_perfil);
        btnTienda = findViewById(R.id.btn_tienda);

        registerForContextMenu(btnClases);
        registerForContextMenu(btnChat);
        registerForContextMenu(btnRM);
        registerForContextMenu(btnPerfil);
        registerForContextMenu(btnTienda);
    }}

