package es.ejemplo.importaciones;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginStaffActivity extends AppCompatActivity {

    EditText email, password;
    Button btnLogin, btnSocio, btnStaff;
    TextView registerLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_staff);

        // Campos
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        btnLogin = findViewById(R.id.btn_login);
        registerLink = findViewById(R.id.register_link);

        // Botones SOCIO / STAFF
        btnSocio = findViewById(R.id.btn_socio);
        btnStaff = findViewById(R.id.btn_staff);

        // Estado inicial: STAFF activo
        activarStaff();

        // Pulsar SOCIO → ir al login socio
        btnSocio.setOnClickListener(v -> {
            Intent intent = new Intent(LoginStaffActivity.this, LoginUserActivity.class);
            startActivity(intent);
        });

        // Pulsar STAFF (solo estilo)
        btnStaff.setOnClickListener(v -> activarStaff());

        // Botón iniciar sesión
        btnLogin.setOnClickListener(v -> {
            if (validarCampos()) {
                Toast.makeText(this, "Login correcto (STAFF)", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LoginStaffActivity.this, LoginUserActivity.class));
            }
        });

        // Enlace registro
        registerLink.setOnClickListener(v -> {
            Intent intent = new Intent(LoginStaffActivity.this, RegisterUserActivity.class);
            startActivity(intent);
        });
    }

    // ---------------------------------------------------
    //   VALIDACIÓN LIMPIA (sin returns dispersos)
    // ---------------------------------------------------
    private boolean validarCampos() {

        boolean valido = true;

        String correo = email.getText().toString().trim();
        String clave = password.getText().toString().trim();

        if (correo.isEmpty()) {
            email.setError("Introduce tu correo");
            valido = false;
        }

        if (clave.isEmpty()) {
            password.setError("Introduce tu contraseña");
            valido = false;
        }

        return valido;
    }

    // ---------------------------------------------------
    //   ESTILO DE BOTONES SOCIO / STAFF
    // ---------------------------------------------------
    private void activarStaff() {

        // STAFF activo
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnStaff.setBackgroundTintList(getColorStateList(R.color.verde_lima));
            btnStaff.setTextColor(getColor(R.color.negro));
        }

        // SOCIO inactivo
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnSocio.setBackgroundTintList(getColorStateList(R.color.gris_oscuro));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnSocio.setTextColor(getColor(R.color.blanco));
        }
    }
}