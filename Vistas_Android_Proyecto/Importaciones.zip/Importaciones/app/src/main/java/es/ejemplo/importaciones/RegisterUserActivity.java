package es.ejemplo.importaciones;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterUserActivity extends AppCompatActivity {

    EditText nombre, email, password, confirmar;
    Spinner spinnerObjetivo;
    CheckBox checkboxPrivacidad;
    Button btnRegistrar, btnSocio, btnStaff;
    TextView loginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register_user);

        // Referencias
        nombre = findViewById(R.id.nombre);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmar = findViewById(R.id.confirmar);
        spinnerObjetivo = findViewById(R.id.spinner_objetivo);
        checkboxPrivacidad = findViewById(R.id.checkbox_privacidad);
        btnRegistrar = findViewById(R.id.btn_registrar);
        btnSocio = findViewById(R.id.btn_socio);
        btnStaff = findViewById(R.id.btn_staff);
        loginLink = findViewById(R.id.login_link);

        // Opciones del Spinner
        String[] objetivos = {
                "Seleccione un objetivo",
                "Perder peso",
                "Ganar masa muscular",
                "Tonificar",
                "Mejorar resistencia",
                "Salud general"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                objetivos
        );
        spinnerObjetivo.setAdapter(adapter);

        // Estado inicial: SOCIO activo
        activarSocio();

        // Pulsar SOCIO
        btnSocio.setOnClickListener(v -> activarSocio());

        // Pulsar STAFF → ir al login staff
        btnStaff.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterUserActivity.this, RegisterStaffActivity.class);
            startActivity(intent);
        });

        // Botón registrar
        btnRegistrar.setOnClickListener(v -> {
            if (validarCampos()) {

                String objetivo = spinnerObjetivo.getSelectedItem().toString();

                Toast.makeText(
                        this,
                        "Registro completado\nObjetivo: " + objetivo,
                        Toast.LENGTH_LONG
                ).show();

                startActivity(new Intent(RegisterUserActivity.this, LoginUserActivity.class));
            }
        });

        // Enlace login
        loginLink.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterUserActivity.this, LoginUserActivity.class);
            startActivity(intent);
        });
    }

    // ---------------------------------------------------
    //   VALIDACIÓN LIMPIA (sin returns dispersos)
    // ---------------------------------------------------
    private boolean validarCampos() {

        boolean valido = true;

        String nom = nombre.getText().toString().trim();
        String correo = email.getText().toString().trim();
        String pass = password.getText().toString().trim();
        String conf = confirmar.getText().toString().trim();

        if (nom.isEmpty()) {
            nombre.setError("Introduce tu nombre");
            valido = false;
        }

        if (correo.isEmpty()) {
            email.setError("Introduce tu correo");
            valido = false;
        }

        if (pass.isEmpty()) {
            password.setError("Introduce una contraseña");
            valido = false;
        }

        if (!pass.equals(conf)) {
            confirmar.setError("Las contraseñas no coinciden");
            valido = false;
        }

        if (!checkboxPrivacidad.isChecked()) {
            Toast.makeText(this, "Debes aceptar las políticas de privacidad", Toast.LENGTH_SHORT).show();
            valido = false;
        }

        return valido;
    }

    // ---------------------------------------------------
    //   ESTILO DE BOTONES SOCIO / STAFF
    // ---------------------------------------------------
    private void activarSocio() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnSocio.setBackgroundTintList(getColorStateList(R.color.verde_lima));
            btnSocio.setTextColor(getColor(R.color.negro));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnStaff.setBackgroundTintList(getColorStateList(R.color.gris_oscuro));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnStaff.setTextColor(getColor(R.color.blanco));
        }
    }
}
